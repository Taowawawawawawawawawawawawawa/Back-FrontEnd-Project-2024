[
  {
           "id": 1,
           "name": "Inception",
           "description": "A thief with the ability to enter peoples dreams takes on the ultimate heist.",
         "length": "148",
         "genre": "Sci-Fi",
         "picture": "base64EncodedPicture1"
     },
     {
         "id": 2,
         "name": "The Dark Knight",
         "description": "Batman faces the Joker, a criminal mastermind.",
         "length": "152",
         "genre": "Action",
         "picture": "base64EncodedPicture2"
     },
     {
         "id": 3,
         "name": "The Shawshank Redemption",
         "description": "Two imprisoned men bond over several years.",
         "length": "142",
         "genre": "Drama",
         "picture": "base64EncodedPicture3"
     },
     {
         "id": 4,
         "name": "The Godfather",
         "description": "The aging patriarch of an organized crime dynasty transfers control to his reluctant son.",
         "length": "175",
         "genre": "Crime",
         "picture": "base64EncodedPicture4"
     },
     {
         "id": 5,
         "name": "Pulp Fiction",
         "description": "The lives of two mob hitmen, a boxer, and others intertwine in four tales.",
         "length": "154",
         "genre": "Crime",
         "picture": "base64EncodedPicture5"
     }
]