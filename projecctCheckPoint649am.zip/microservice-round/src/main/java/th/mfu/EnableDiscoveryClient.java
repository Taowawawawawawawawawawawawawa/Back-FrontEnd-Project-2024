package th.mfu;

public @interface EnableDiscoveryClient {

}
