INSERT INTO customer (id, name, age, phoneNum, pass) VALUES
(1, 'John Doe', 28, '555-1234', 'password123'),
(2, 'Jane Smith', 35, '555-5678', 'securePass'),
(3, 'Alice Johnson', 24, '555-8765', 'alicePass'),
(4, 'Bob Williams', 40, '555-4321', 'bobPassword');
